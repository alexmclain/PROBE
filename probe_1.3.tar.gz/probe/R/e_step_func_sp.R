#' @title Spatial empirical Bayes E-step using spatially-weighted KDE or CNF and a local truncated normal null
#' @description Estimates posterior expectations of the \eqn{\gamma} variables for the spatial PROBE
#' algorithm. For each predictor location, test statistics are pooled from spatial neighbors using
#' Gaussian kernel weights. The marginal density is estimated via either a weighted KDE
#' (\code{method = "kde"}, default) or a conditional normalizing flow neural network
#' (\code{method = "cnf"}), and the null density is estimated via a locally-weighted truncated normal
#' model with variance constrained to be at least one. Local \eqn{\pi_0} estimates follow the
#' weighted Storey method.
#' @usage e_step_func_sp(beta_t, beta_var, df, Dfull_grid, neighbor_list,
#' h_spatial = NULL, h_z = NULL, radius = NULL, null_frac = 0.70,
#' lambda = 0.5, min_neighbors = 10, lambda_tau = 0.1, H = NULL, coord_leng,
#' method = c("kde", "cnf"), coords = NULL, estimate_sigma = TRUE, sigma_null = 1,
#' cnf_model = NULL, cnf_K = 10, cnf_hidden_dim = 64, cnf_n_hidden = 2,
#' cnf_n_epochs = 1000, cnf_lr = 1e-3, cnf_batch_size = 256)
#' @param beta_t Numeric vector of posterior mean expectations (assuming \eqn{\gamma=1}).
#' @param beta_var Numeric vector of current posterior variances (assuming \eqn{\gamma=1}).
#' @param df Degrees of freedom for the t-distribution used to compute p-values.
#' @param Dfull_grid An \code{M x M} matrix of pairwise distances between all predictor locations
#' (e.g., from \code{fields::rdist(coords)}).
#' @param neighbor_list A precomputed list of length \code{M}, where element \code{i} contains the
#' integer indices of spatial neighbors for location \code{i}.
#' @param h_spatial Spatial Gaussian kernel bandwidth. If \code{NULL}, uses a heuristic based on
#' the median pairwise distance.
#' @param h_z KDE bandwidth in the test statistic space. If \code{NULL}, uses a weighted Silverman
#' rule of thumb computed within each neighborhood.
#' @param radius Neighbor radius used to construct \code{neighbor_list} (informational; passed through
#' to diagnostic output).
#' @param null_frac Fraction of central (near-zero) test statistics used to define the local null
#' region (default = 0.70).
#' @param lambda Storey tuning parameter for local \eqn{\pi_0} estimation (default = 0.5).
#' @param min_neighbors Minimum number of neighbors required for local estimation. Locations with fewer
#' neighbors fall back to using all \code{M} predictors (default = 10).
#' @param lambda_tau Ridge-type penalty on the local null variance estimate to prevent instability
#' in sparse neighborhoods (default = 0.1).
#' @param H (optional) True signal matrix, used only for diagnostic image plots when \code{verbose = TRUE}
#' inside the inner function.
#' @param coord_leng Integer vector of coordinate dimension lengths (e.g., \code{c(nx, ny)} for a
#' 2D grid) used to reshape results into matrices for verbose diagnostic plots.
#' @param method Density estimation method for the marginal distribution. \code{"kde"} (default)
#' uses spatially-weighted kernel density estimation. \code{"cnf"} uses a conditional normalizing
#' flow (neural-network mixture-of-logistics) and requires the \code{torch} package along with
#' the helper functions \code{train_cnf}, \code{estimate_f_cnf}, and \code{lfdr_threshold}.
#' @param coords (required when \code{method = "cnf"}) An \code{M x d} matrix of spatial
#' coordinates for each predictor location.
#' @param estimate_sigma Logical; only used when \code{method = "cnf"}. If \code{TRUE} (default),
#' estimates the local null variance via a weighted truncated-normal MLE with shrinkage. If
#' \code{FALSE}, fixes null SD to \code{sigma_null}.
#' @param sigma_null Fixed null SD used when \code{method = "cnf"} and \code{estimate_sigma = FALSE}
#' (default = 1).
#' @param cnf_model A previously fitted CNF model (the \code{$cnf_model} element from a prior call
#' with \code{method = "cnf"}). When supplied, training is skipped. Ignored for \code{method = "kde"}.
#' @param cnf_K Number of mixture-of-logistics components for the CNF (default = 10).
#' @param cnf_hidden_dim Conditioner network width for the CNF (default = 64).
#' @param cnf_n_hidden Number of hidden layers in the CNF conditioner (default = 2).
#' @param cnf_n_epochs Adam training epochs for the CNF (default = 1000).
#' @param cnf_lr Adam learning rate for the CNF (default = 1e-3).
#' @param cnf_batch_size Mini-batch size for CNF training (default = 256).
#' @return A list including
#'
#' \code{gamma} estimated posterior expectations of the \eqn{\gamma} variables,
#'
#' \code{lfdr} estimated local false discovery rates (\eqn{1 - \gamma}),
#'
#' \code{pi0} local estimates of the proportion of null hypotheses,
#'
#' \code{p_vals} two-sided p-values computed from the t-distribution,
#'
#' \code{T_vals} test statistics (\eqn{\hat{\beta} / \sqrt{\widehat{\mathrm{Var}}(\hat{\beta})}}),
#'
#' \code{beta_tilde} posterior mean expectations (equal to input \code{beta_t}),
#'
#' \code{beta_tilde_var} posterior variances (equal to input \code{beta_var}),
#'
#' \code{adj_warning} integer flag (1 if the marginal density appears too narrow relative to the null density, 0 otherwise).
#' @references 
#' \itemize{  \item McLain, AC, A Zgodic, H Bondell (2025). Sparse high-dimensional linear regression with a partitioned empirical Bayes ECM algorithm. \emph{Computational Statistics and Data Analysis} 207, 108146.
#' \item Zgodic, A., Bai, R., Zhang, J., Wang, Y., Rorden, C., & McLain, AC. (2026). Quantifying predictive uncertainty of aphasia severity in stroke patients with sparse heteroscedastic Bayesian high-dimensional regression. \emph{Computational Statistics} 41:7, 1 -- 23.
#' \item Storey, J. D., Taylor, J. E., and Siegmund, D. (2004), “Strong control, conservative point estimation and simultaneous conservative consistency of false discovery rates: A unified approach,” \emph{J. R. Stat. Soc. Ser. B. Stat. Methodol.}, 66, 187–205.
#' }
#' @examples
#' #not run
#'
#' @importFrom stats approxfun dnorm optimize pnorm
#' @importFrom graphics par

e_step_func_sp <- function(beta_t, beta_var, df,
                           Dfull_grid,
                           neighbor_list,
                           h_spatial = NULL,       # spatial kernel bandwidth (if NULL use heuristic)
                           h_z = 1,               # KDE bandwidth in z multiplier (if 1 uses Silverman-ish)
                           radius = NULL,          # neighbor radius in grid units (if NULL use heuristic)
                           null_frac = 0.70,       # fraction of central Z to treat as local null
                           lambda = 0.5,           # Storey tuning
                           min_neighbors = 10,     # fallback if too few neighbors
                           lambda_tau = 0.1,       # Penalty for estimate of sigma
                           H = NULL,
                           coord_leng,
                           verbose = FALSE,
                           method = c("kde", "cnf"),
                           coords = NULL,          # required for method = "cnf"
                           estimate_sigma = TRUE,  # CNF: estimate local null sigma (TRUE) or fix to sigma_null
                           sigma_null = 1,         # CNF: fixed null SD when estimate_sigma = FALSE
                           cnf_model = NULL,       # CNF: pre-fitted model to skip retraining
                           cnf_K = 10,
                           cnf_hidden_dim = 64,
                           cnf_n_hidden = 2,
                           cnf_n_epochs = 1000,
                           cnf_lr = 1e-3,
                           cnf_batch_size = 256
                           ){
  method <- match.arg(method)

  ### Get and clean up T statistics
  T_vals <- beta_t/sqrt(beta_var)
  T_vals[beta_var<=0] <- 0
  T_vals[is.na(T_vals)] <- 0
  T_vals[is.nan(T_vals)] <- 0
  p_vals <- pt(abs(T_vals), df = df, lower.tail = FALSE) * 2

  # ---- CNF branch ----
  if (method == "cnf") {
    if (is.null(coords))
      stop("coords must be provided when method = 'cnf'.")
    if (!requireNamespace("torch", quietly = TRUE))
      stop("Package 'torch' is required for method = 'cnf'. Install with install.packages('torch').")
    # Reshape T_vals to matrix expected by spatial_lfdr_cnf
    if (length(coord_leng) == 2) {
      T_mat <- matrix(T_vals, nrow = coord_leng[1], ncol = coord_leng[2])
    } else {
      T_mat <- matrix(T_vals, ncol = 1)
    }
    cnf_res <- spatial_lfdr_cnf(
      Z              = T_mat,
      coords         = coords,
      h_spatial      = h_spatial,
      Dfull_grid     = Dfull_grid,
      radius         = radius,
      null_frac      = null_frac,
      lambda         = lambda,
      min_neighbors  = min_neighbors,
      estimate_sigma = estimate_sigma,
      sigma_null     = sigma_null,
      lambda_tau     = lambda_tau,
      H              = H,
      eps            = 1e-12,
      cnf_model      = cnf_model,
      cnf_K          = cnf_K,
      cnf_hidden_dim = cnf_hidden_dim,
      cnf_n_hidden   = cnf_n_hidden,
      cnf_n_epochs   = cnf_n_epochs,
      cnf_lr         = cnf_lr,
      cnf_batch_size = cnf_batch_size,
      verbose        = verbose
    )
    lfdr_vec <- as.numeric(cnf_res$lfdr)
    gamma    <- 1 - lfdr_vec

    ret <- list(
      gamma       = gamma,
      lfdr        = lfdr_vec,
      pi0         = as.numeric(cnf_res$pi0),
      p_vals      = p_vals,
      T_vals      = T_vals,
      EB_res      = cnf_res,
      cnf_model   = cnf_res$cnf_model,
      adj_warning = 0
    )
  }else{

  # ---- KDE branch (default) ----
  EB_res <- spatial_nonparam_kde_truncnorm(T_vals,
                                           p_vals,
                                           Dfull_grid,
                                           neighbor_list, # list of neighbors
                                           h_spatial,
                                           h_z,          # KDE bandwidth in z (if NULL use Silverman-ish)
                                           radius,       # neighbor radius in grid units (if NULL use 6)
                                           null_frac,    # fraction of central Z to treat as local null
                                           lambda,        # Storey tuning
                                           min_neighbors,  # fallback if too few neighbors
                                           lambda_tau,     # Penalty for estimate of sigma
                                           df,
                                           H,            # True value of the signals
                                           eps = 1e-12,
                                           coord_leng,
                                           verbose = verbose)
  lfdr_vec <- as.numeric(EB_res$lfdr)
  gamma <- 1-lfdr_vec
  adj_warning <- EB_res$adj_warning
  
  ret <- list(gamma = gamma,
              lfdr = lfdr_vec,
              pi0 = EB_res$pi0,
              p_vals = p_vals,
              T_vals = T_vals,
              EB_res = EB_res,
              adj_warning = adj_warning)
  }

  return(ret)
}





spatial_nonparam_kde_truncnorm <- function(T_vals,
                                           p_vals,
                                           Dfull_grid,
                                           neighbor_list, # list of neighbors
                                           h_spatial = 0.1, 
                                           h_z = 1,          # KDE bandwidth in z multiplyer 
                                           radius = NULL,       # neighbor radius in grid units (if NULL use 6)
                                           null_frac = 0.70,    # fraction of central Z to treat as local null 
                                           lambda = 0.5,        # Storey tuning
                                           min_neighbors = 10,  # fallback if too few neighbors
                                           lambda_tau = 0.1,     # Penalty for estimate of sigma
                                           df = 40,
                                           H = NULL,            # True value of the signals
                                           eps = 1e-12,
                                           coord_leng,
                                           verbose = TRUE) {
  
  n <- length(T_vals)
  
  # precompute p-values and global central threshold 
  z_thres <- as.numeric(stats::quantile(abs(T_vals), probs = null_frac, na.rm = TRUE))
  z_abs_q <- abs(T_vals) <= z_thres
  
  # precompute a global marginal KDE for fallback
  temp_h_z <- h_z
  if (is.null(h_z)) {
    # Silverman-ish bandwidth on T_vals (local)
    temp_h_z <- weighted_h(T_vals) 
  }
  global_kde <- stats::density(T_vals, bw = temp_h_z)
  global_fun <- approxfun(global_kde$x, global_kde$y, rule = 2)
  
  # allocate result vectors
  f_hat_vec <- numeric(n)
  f0_hat_vec <- numeric(n)
  pi0_vec <- numeric(n)
  lfdr_vec <- numeric(n)
  h_z_vec <- numeric(n)
  sigma_vec <- numeric(n)
  lfdr_at_0_vec <- numeric(n)
  
  global_sigma <- wt_truncnorm_sigma_ge1(T_vals[z_abs_q], rep(1,sum(z_abs_q)), t = z_thres)

  mx_i <- which.max(abs(T_vals))
  # loop locations (can be parallelized)
  for (i in seq_len(n)) {
    
    neigh <- neighbor_list[[i]]
    if (length(neigh) < min_neighbors) {
      # expand to full grid if too few neighbors
      neigh <- seq_len(n)
    }
    # spatial weights: Gaussian on distance^2
    d2 <- Dfull_grid[neigh,i]^2
    w_spatial <- exp(- d2 / (2 * h_spatial^2))
    if (sum(w_spatial) <= 0) w_spatial <- rep(1, length(w_spatial))
    # ---- marginal f: weighted KDE on observed Z in neighborhood ----
    samples_obs <- T_vals[neigh]
    
      # Silverman-ish bandwidth on T_vals (local)
    temp_h_z <- h_z*weighted_h(samples_obs, w_spatial) 

    f_hat_i <- tryCatch(weighted_kde_eval(samples_obs, w_spatial, T_vals[i], temp_h_z),
                        error = function(e) global_fun(T_vals[i]))

    # fallback
    if (!is.finite(f_hat_i) || f_hat_i <= 0) f_hat_i <- max(global_fun(T_vals[i]), eps)
    f_hat_vec[i] <- f_hat_i
    # ---- null f0 estimation ----
    # central mask among neigh
    central_mask <- z_abs_q[neigh]
    if (sum(central_mask) < min_neighbors) {
      # if too few central points, fall back to global central threshold across all neighbors, else to global KDE
      central_mask <- rep(TRUE, length(neigh))
    }
    samples_null <- T_vals[neigh][central_mask]
    weights_null <- w_spatial[central_mask]
    
    
    
    if (length(samples_null) < 3) {
      # fallback: use global estimate of sigma
      # f0_i <- dt(T_vals[i]/global_sigma, df = df)/global_sigma
      f0_i <- dnorm(T_vals[i],mean = 0, sd = global_sigma)
      sigma_vec[i] <- global_sigma
    } else {
      # Estimate sigma
      est_sigma <- wt_truncnorm_sigma_ge1(samples_null, weights_null, t = z_thres, lambda_tau = lambda_tau)
      # f0_i <- dt(T_vals[i]/est_sigma, df = df)/est_sigma
      f0_i <- dnorm(T_vals[i],mean = 0, sd = est_sigma)
      sigma_vec[i] <- est_sigma
    }
    

    
    if (!is.finite(f0_i) || f0_i <= 0) f0_i <- eps
    f0_hat_vec[i] <- f0_i
    # ---- local pi0 via weighted Storey ----
    p_neigh <- p_vals[neigh]
    w_p <- w_spatial
    numer <- sum(w_p * (p_neigh > lambda))
    denom <- (1 - lambda) * sum(w_p)
    pi0_i <- min(1, numer / max(denom, eps))
    pi0_vec[i] <- pi0_i
    
    if(i == mx_i & verbose){
      x <- seq(-6,6, 0.1)
      f_est_x <- numeric(length(x))
      for(xi in 1:length(x)){
        f_est_x[xi] <- weighted_kde_eval(samples_obs, w_spatial, x[xi], temp_h_z)
      }
      # f0_est_x <- dt(x/est_sigma, df = df)/est_sigma
      f0_est_x <- dnorm(x,mean = 0, sd = est_sigma)
      f0_est_x_pi0 <- pi0_i*f0_est_x
      lfdr_est_x <- f0_est_x_pi0/f_est_x

    }
    
    # ---- lfdr plug-in and clamp ----
    lfdr_i <- min(1, pi0_i * f0_i / f_hat_i)
    lfdr_vec[i] <- max(0, min(1, lfdr_i))
    h_z_vec[i] <- temp_h_z
    # lfdr_at_0_vec[i] <- weighted_kde_eval(samples_obs, w_spatial, 0, temp_h_z)/(dt(0, df = df)/est_sigma)
    lfdr_at_0_vec[i] <- weighted_kde_eval(samples_obs, w_spatial, 0, temp_h_z)/(dnorm(0, mean = 0, sd = est_sigma))
  } # end loop
  
  if(length(coord_leng) == 2){
    # reshape to matrices
    if (verbose) {
      lfdr_mat <- matrix(lfdr_vec, nrow = coord_leng[1], ncol = coord_leng[2], byrow = FALSE)
      f_mat <- matrix(f_hat_vec, nrow = coord_leng[1], ncol = coord_leng[2], byrow = FALSE)
      f0_mat <- matrix(f0_hat_vec, nrow = coord_leng[1], ncol = coord_leng[2], byrow = FALSE)
      pi0_mat <- matrix(pi0_vec, nrow = coord_leng[1], ncol = coord_leng[2], byrow = FALSE)
      h_z_mat <- matrix(h_z_vec, nrow = coord_leng[1], ncol = coord_leng[2], byrow = FALSE)
      sigma_mat <- matrix(sigma_vec, nrow = coord_leng[1], ncol = coord_leng[2], byrow = FALSE)
      T_vals_mat <- matrix(T_vals, nrow = coord_leng[1], ncol = coord_leng[2], byrow = FALSE)
      op <- par(no.readonly = TRUE)
      par(mfrow = c(3,3), mar = c(2,2,2,2)+2)
      if (!is.null(H)){
        fields::image.plot(t(H)[, nrow(H):1], main = "True H (mask)")
      }else{
        hist(p_vals, main = "Observed p histogram", breaks = 40, col = gray(0.9))
      }
      fields::image.plot(t(T_vals_mat)[, nrow(T_vals_mat):1], main = "Observed T")
      fields::image.plot(t(lfdr_mat)[, nrow(lfdr_mat):1], main = "Estimated lfdr")
      fields::image.plot(t(f0_mat)[, nrow(lfdr_mat):1], main = "Estimated f0")
      fields::image.plot(t(f_mat)[, nrow(lfdr_mat):1], main = "Estimated f")
      fields::image.plot(t(pi0_mat)[, nrow(lfdr_mat):1], main = "Estimated pi0")
      fields::image.plot(t(h_z_mat)[, nrow(lfdr_mat):1], main = "Bandwidth")
      fields::image.plot(t(sigma_mat)[, nrow(lfdr_mat):1], main = "Estimated Null Sigma")
      big_vec <- c(f0_est_x,f_est_x, lfdr_est_x)
      big_vec[big_vec>1] <- 1
      plot(x,f_est_x, type = "l", ylim = range(big_vec), main = "Distributions at max|T|")
      lines(x, f0_est_x, col = 2)
      lines(x, f0_est_x_pi0, col = 3)
      lines(x, lfdr_est_x, col = 4)
      abline(v = T_vals[mx_i])
      #plot(sort(array(lfdr_mat)), type = "l", main = "Sorted lfdr values")
      tryCatch(par(op), error = function(e) NULL)
    }
  }
  
  ## Bandwidth warning:
  adj_warning = 0
  if(any(lfdr_at_0_vec > 1.5)){
    adj_warning = 1
  }
  
  
  return(list(lfdr = lfdr_vec,
              f = f_hat_vec,
              f0 = f0_hat_vec,
              pi0 = pi0_vec,
              h_z = h_z_vec,
              sigma = sigma_vec,
              f_f0_rat_at_0_vec = lfdr_at_0_vec,
              params = list(h_spatial = h_spatial, h_z = h_z, radius = radius, null_frac = null_frac),
              neighbor_list = neighbor_list, 
              adj_warning = adj_warning))
}




# This uses a parametric normal local null with mean fixed at zero and 
# variance constrained to be at least one, estimated locally via weighted 
# likelihood, with shrinkage to stabilize the fit.
wt_truncnorm_sigma_ge1 <- function(z0, w0, t = 2, lambda_tau = 0.1) {
  
  neglog <- function(theta) {
    mu <- 0; sigma <- theta[1]
    a <- (-t - mu) / sigma; b <- (t - mu) / sigma
    Znorm <- pnorm(b) - pnorm(a)
    if (Znorm <= 1e-12) return(1e20)
    u <- (z0 - mu) / sigma
    logpdf <- dnorm(u, log = TRUE) - log(sigma) - log(Znorm)
    nll <- -sum(w0 * logpdf) + 0.5 * lambda_tau * (sigma - 1)^2
    nll
  }
  opt <- optimize(neglog, c(1, 20))
  sigma_hat <- opt$minimum
  sigma_hat
}


# weighted KDE evaluator (Gaussian kernel). samples: numeric vector, weights: same length
weighted_kde_eval <- function(samples, weights, x0, h, eps = 1e-12) {
  # small defensive checks
  if (length(samples) == 0) return(eps)
  # avoid zero total weight
  wsum <- sum(weights)
  if (wsum <= 0) return(eps)
  u <- (x0 - samples) / h
  # Gaussian kernel density
  ker_vals <- dnorm(u)
  val <- sum(weights * ker_vals) / (h * wsum)
  # guard
  if (!is.finite(val) || val <= 0) return(eps)
  return(val)
}

# Calculates the bandwidth using the Silverman rule with weights.
# The weights are used to calculate a weighted sd and the effective
# sample size.
weighted_h <- function(samples_obs, w = NULL) {
  if(is.null(w)) w <- rep(1,length(samples_obs))
  # Silverman-ish bandwidth on T_vals (local)
  sd_z <- max(c(weighted_sd(samples_obs, w),1))
  n_eff <- length(w)
  temp_h_z <- 1.06 * sd_z * n_eff^(-1/5)
  if (temp_h_z <= 0 || is.na(temp_h_z)) temp_h_z <- 0.3
  temp_h_z
}

# Calculates a weighted standard deviation.
weighted_sd <- function(x, w) {
  mu <- sum(w * x) / sum(w)
  sqrt(sum(w * (x - mu)^2) / sum(w))
}


# ------------------------------------------------------------------
# spatial_lfdr_cnf
#
# Spatial lfdr estimation using a conditional normalizing flow (CNF)
# neural-network mixture-of-logistics model for the marginal density
# f(z | s), a local weighted Storey estimator for pi0(s), and an
# optional local null variance estimation via a truncated N(0, sigma^2)
# model with shrinkage.
#
# Requires the 'torch' package and the helper functions:
#   train_cnf(), estimate_f_cnf(), lfdr_threshold()
#
# Arguments
# ---------
# Z             : nrow x ncol matrix of observed Z-/T-statistics
# coords        : n x 2 coordinate matrix (column-major order, n = nrow*ncol)
# h_spatial     : spatial Gaussian kernel bandwidth; auto-computed from
#                 Dfull_grid if NULL
# Dfull_grid    : n x n distance matrix; used only when h_spatial = NULL
# radius        : neighbour radius in grid units (default: max(3, min_dim/8))
# null_frac     : central fraction of |Z| used to identify null obs when
#                 estimating sigma locally (default 0.70)
# lambda        : Storey tuning parameter for pi0 (default 0.5)
# min_neighbors : fall back to all locations if neighbourhood < this (10)
# alpha         : target FDR level for lfdr thresholding (default 0.1)
# estimate_sigma: if TRUE (default), estimate null sigma locally via
#                 weighted truncated-normal MLE with shrinkage.
#                 if FALSE, fix null sigma = sigma_null at every location.
# sigma_null    : fixed null SD used when estimate_sigma = FALSE (default 1)
# lambda_tau    : shrinkage penalty toward sigma = 1 in local MLE;
#                 only used when estimate_sigma = TRUE (default 0.001)
# H             : true signal indicator matrix (optional; for diagnostics)
# eps           : numerical floor (default 1e-12)
# cnf_model     : a previously fitted CNF model returned by an earlier call
#                 (the $cnf_model element). When supplied, training is skipped
#                 and all cnf_* tuning parameters below are ignored.
# cnf_K         : MoL mixture components (default 10)
# cnf_hidden_dim: conditioner network width (default 64)
# cnf_n_hidden  : conditioner hidden layers (default 2)
# cnf_n_epochs  : Adam training epochs (default 1000)
# cnf_lr        : Adam learning rate (default 1e-3)
# cnf_batch_size: mini-batch size for training (default 256)
# verbose       : print progress and plots (default TRUE)
#
# Returns a list with:
#   lfdr, f, f0, pi0, sigma_mat  — matrices (nrow x ncol)
#   thresh_info                  — output of lfdr_threshold()
#   cnf_model                    — fitted CNF model object
#   params                       — list of run parameters
#   neighbor_list                — list of neighbour index vectors
# ------------------------------------------------------------------
spatial_lfdr_cnf <- function(Z,
                             coords,
                             h_spatial      = NULL,
                             Dfull_grid     = NULL,
                             radius         = NULL,
                             null_frac      = 0.70,
                             lambda         = 0.5,
                             min_neighbors  = 10,
                             alpha          = 0.1,
                             estimate_sigma = TRUE,
                             sigma_null     = 1,
                             lambda_tau     = 0.001,
                             H              = NULL,
                             eps            = 1e-12,
                             cnf_model      = NULL,
                             cnf_K          = 10,
                             cnf_hidden_dim = 64,
                             cnf_n_hidden   = 2,
                             cnf_n_epochs   = 1000,
                             cnf_lr         = 1e-3,
                             cnf_batch_size = 256,
                             verbose        = TRUE) {

  nrow_ <- nrow(Z)
  ncol_ <- ncol(Z)
  n     <- nrow_ * ncol_
  Zvec  <- as.numeric(Z)

  # ---- radius and spatial bandwidth ----
  if (is.null(radius)) radius <- max(3, min(nrow_, ncol_) / 8)
  if (is.null(h_spatial)) {
    if (is.null(Dfull_grid))
      stop("Provide either h_spatial or Dfull_grid.")
    h_spatial <- median(Dfull_grid[upper.tri(Dfull_grid)]) / 6
    if (is.na(h_spatial) || h_spatial <= 0) h_spatial <- 3
  }

  if (verbose)
    message("spatial_lfdr_cnf: n = ", n,
            ", radius = ", radius,
            ", h_spatial = ", round(h_spatial, 3),
            ", estimate_sigma = ", estimate_sigma,
            if (!estimate_sigma) paste0("  (fixed sigma_null = ", sigma_null, ")") else "")

  # ---- neighbour lists ----
  neighbor_list <- vector("list", n)
  radius2 <- radius^2
  for (i in seq_len(n)) {
    d2 <- (coords[, 1] - coords[i, 1])^2 + (coords[, 2] - coords[i, 2])^2
    neighbor_list[[i]] <- which(d2 <= radius2)
  }

  # ---- global quantities ----
  pvals   <- 2 * (1 - pnorm(abs(Zvec)))
  z_thres <- as.numeric(quantile(abs(Zvec), probs = null_frac, na.rm = TRUE))
  z_abs_q <- abs(Zvec) <= z_thres   # central-null mask (logical, length n)

  global_sigma <- if (estimate_sigma) {
    wt_truncnorm_sigma_ge1(Zvec[z_abs_q], rep(1, sum(z_abs_q)), t = z_thres,
                           lambda_tau = lambda_tau)
  } else {
    sigma_null
  }

  if (verbose && estimate_sigma)
    message("  global null sigma = ", round(global_sigma, 3))

  # ---- train CNF (or reuse supplied model) and evaluate f ----
  if (is.null(cnf_model)) {
    if (verbose) message("Training CNF (neural network MoL, requires torch) ...")
    cnf_model <- train_cnf(Z, coords,
                           K          = cnf_K,
                           hidden_dim = cnf_hidden_dim,
                           n_hidden   = cnf_n_hidden,
                           n_epochs   = cnf_n_epochs,
                           lr         = cnf_lr,
                           batch_size = cnf_batch_size,
                           verbose    = verbose)
  } else {
    if (verbose) message("Using supplied CNF model (skipping training).")
  }
  f_hat_vec <- estimate_f_cnf(Z, coords, cnf_model)

  # ---- per-location loop: f0, pi0, lfdr ----
  f0_hat_vec <- numeric(n)
  pi0_vec    <- numeric(n)
  lfdr_vec   <- numeric(n)
  sigma_vec  <- numeric(n)

  for (i in seq_len(n)) {

    neigh <- neighbor_list[[i]]
    if (length(neigh) < min_neighbors) neigh <- seq_len(n)

    d2        <- (coords[neigh, 1] - coords[i, 1])^2 +
                 (coords[neigh, 2] - coords[i, 2])^2
    w_spatial <- exp(-d2 / (2 * h_spatial^2))
    if (sum(w_spatial) <= 0) w_spatial <- rep(1, length(w_spatial))

    # ---- null sigma ----
    if (estimate_sigma) {
      central_mask <- z_abs_q[neigh]
      if (sum(central_mask) < min_neighbors)
        central_mask <- rep(TRUE, length(neigh))
      samples_null  <- Zvec[neigh][central_mask]
      weights_null  <- w_spatial[central_mask]
      if (length(samples_null) < 3) {
        est_sigma <- global_sigma
      } else {
        est_sigma <- wt_truncnorm_sigma_ge1(samples_null, weights_null,
                                            t = z_thres,
                                            lambda_tau = lambda_tau)
      }
    } else {
      est_sigma <- sigma_null
    }
    sigma_vec[i] <- est_sigma

    # ---- f0 ----
    f0_i <- dnorm(Zvec[i], 0, est_sigma)
    if (!is.finite(f0_i) || f0_i <= 0) f0_i <- eps
    f0_hat_vec[i] <- f0_i

    # ---- pi0 via local Storey ----
    numer      <- sum(w_spatial * (pvals[neigh] > lambda))
    denom      <- (1 - lambda) * sum(w_spatial)
    pi0_vec[i] <- min(1, numer / max(denom, eps))

    # ---- lfdr ----
    lfdr_vec[i] <- max(0, min(1, pi0_vec[i] * f0_i / max(f_hat_vec[i], eps)))
  }

  # ---- reshape to matrices ----
  lfdr_mat  <- matrix(lfdr_vec,   nrow = nrow_, ncol = ncol_, byrow = FALSE)
  f_mat     <- matrix(f_hat_vec,  nrow = nrow_, ncol = ncol_, byrow = FALSE)
  f0_mat    <- matrix(f0_hat_vec, nrow = nrow_, ncol = ncol_, byrow = FALSE)
  pi0_mat   <- matrix(pi0_vec,    nrow = nrow_, ncol = ncol_, byrow = FALSE)
  sigma_mat <- matrix(sigma_vec,  nrow = nrow_, ncol = ncol_, byrow = FALSE)

  # ---- diagnostic plots ----
  if (verbose) {
    op <- par(no.readonly = TRUE)
    par(mfrow = c(3, 3), mar = c(2, 2, 2, 1))
    if (!is.null(H)) {
      fields::image.plot(t(H)[, nrow(H):1],       main = "True H (mask)")
    } else {
      hist(pvals, main = "Observed p histogram", breaks = 40, col = gray(0.9))
    }
    fields::image.plot(t(Z)[, nrow(Z):1],          main = "Observed Z")
    fields::image.plot(t(lfdr_mat)[, nrow_:1],     main = "Estimated lfdr (CNF)")
    fields::image.plot(t(f0_mat)[, nrow_:1],       main = "Estimated f0")
    fields::image.plot(t(f_mat)[, nrow_:1],        main = "Estimated f (CNF)")
    fields::image.plot(t(pi0_mat)[, nrow_:1],      main = "Estimated pi0")
    if (estimate_sigma) {
      fields::image.plot(t(sigma_mat)[, nrow_:1],  main = "Estimated null sigma")
    } else {
      plot.new()
      title(main = paste0("Fixed null sigma = ", sigma_null))
    }
    plot.new()
    plot(sort(as.numeric(lfdr_mat)), type = "l", main = "Sorted lfdr values")
    tryCatch(par(op), error = function(e) NULL)
  }

  # ---- threshold ----
  res_thresh <- lfdr_threshold(lfdr_mat = lfdr_mat, alpha = alpha,
                               true_H = H, nrow_ = nrow_, ncol_ = ncol_,
                               verbose = verbose)

  if (verbose) {
    op2 <- par(no.readonly = TRUE)
    par(mfrow = c(1, 3))
    if (!is.null(H)) fields::image.plot(t(H)[, nrow_:1], main = "True Signals")
    fields::image.plot(t(lfdr_mat)[, nrow_:1],   main = "Estimated lfdr")
    fields::image.plot(t(res_thresh$reject_mat)[, nrow_:1],
                       main = paste0("Rejections (alpha = ", alpha, ")"))
    tryCatch(par(op2), error = function(e) NULL)
  }

  return(list(
    lfdr         = lfdr_mat,
    f            = f_mat,
    f0           = f0_mat,
    pi0          = pi0_mat,
    sigma_mat    = sigma_mat,
    thresh_info  = res_thresh,
    cnf_model    = cnf_model,
    params       = list(
      h_spatial      = h_spatial,
      radius         = radius,
      null_frac      = null_frac,
      estimate_sigma = estimate_sigma,
      sigma_null     = sigma_null,
      lambda_tau     = lambda_tau,
      cnf_K          = cnf_K,
      cnf_hidden_dim = cnf_hidden_dim,
      cnf_n_hidden   = cnf_n_hidden,
      cnf_n_epochs   = cnf_n_epochs,
      cnf_lr         = cnf_lr
    ),
    neighbor_list = neighbor_list
  ))
}
